<?php
/**
 * Advanced Mobile Device Detection
 *
 * @version		1.2.5.1
 * @license		GNU/GPL v2 - http://www.gnu.org/licenses/gpl-2.0.html
 * @copyright	(C) 2008-2013 Kuneri Ltd.
 * @date		March 2013
 */

class AmddDatabaseJoomlaConfig
{
	public static $dbTableName = '#__mj_amdd';
}