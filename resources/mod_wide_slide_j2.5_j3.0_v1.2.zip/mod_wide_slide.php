<?php
/*
* Pixel Point Creative - Wide Slide Module
* License: GNU General Public License version
* See: http://www.gnu.org/copyleft/gpl.html
* Copyright (c) Pixel Point Creative LLC.
* More info at http://www.pixelpointcreative.com
* Last Updated: 3/29/13
*/
defined( '_JEXEC' ) or die( 'Restricted access' );
if (!defined("DS")) {
	define('DS', DIRECTORY_SEPARATOR);
}
$document = &JFactory::getDocument();
jimport('joomla.filesystem.folder');
jimport( 'joomla.html.html' );

require (dirname(__FILE__). DS . 'classes' . DS . 'wideslide.php');
Wideslide::setModule($module);
require_once (dirname(__FILE__).DS.'helper.php');
$folder 			= 	$params->get( 'folder', 'images/gallery' );
$item_default 		= 	$params->get( 'item_default', '1' );
if ($item_default > 0) {
	$item_default 		=   (int)$item_default - 1;
} else {
	$item_default = 0;
}
$descriptions 		= 	$params->get( 'description',"");
$orderby 		= 	$params->get( 'orderby', 0);
$sort 			= 	$params->get( 'sort', '1');
$lwidth 		= 	$params->get( 'lwidth', 550 );
$lheight 		= 	$params->get( 'lheight', 200 );
$twidth 		= 	$params->get( 'twidth', 550 );
$theight 		= 	$params->get( 'theight', 200 );
$show_button 		= 	$params->get( 'show_button', 1 );
$show_thumb 		= 	$params->get( 'show_thumb', 1 );
$auto_play 		= 	$params->get( 'auto_play', 1 );
$speed2			= 	intval($params->get( 'speed2', 5000 ));
$loop 			= 	$params->get( 'loop', 1 );
$showCaption 		= 	$params->get( 'show_caption', 1 );
$showDesc 		= 	$params->get( 'show_desc', 1 );
$showReadmore 		= 	$params->get( 'show_readmore', 1 );
$readmoreText 		= 	$params->get( 'readmoreText', JText::_('Read more') );
$show_time 		= 	$params->get( 'show_time', 1 );
$duration 		= 	intval($params->get( 'duration', 1000 ));
$pause			= 	intval($params->get( 'pause', 5000 ));
$caption_color 		= 	$params->get( 'caption_color', '#FFFFFF' );
$desc_color 		= 	$params->get( 'desc_color', '#FFCC33' );
$readmore_color 	= 	$params->get( 'readmore_color', '#919191' );
$jquery			= 	$params->get('include_jquery', '1');

	JHTML::stylesheet('fonts.googleapis.com/css?family=Open+Sans', 'http://');
	JHtml::stylesheet('modules/'.$module->module.'/assets/css/style.css');
		if( !defined('SMART_JQUERY') && $jquery ){
		JHtml::script('modules/'.$module->module.'/assets/js/jquery-1.8.2.min.js');
		JHtml::script('modules/'.$module->module.'/assets/js/jquery-noconflict.js');
		define('SMART_JQUERY', 1);
	} 
	
	JHTML::script('modules/'.$module->module.'/assets/js/jquery-ui.min.js');
	JHTML::script('modules/'.$module->module.'/assets/js/css3-mediaqueries.js');
	JHtml::script('modules/'.$module->module.'/assets/js/fwslider.js');

$photo = modWideSlide::getInstance($params);
$items = $photo->getInfo($params);
$path = JModuleHelper::getLayoutPath( 'mod_wide_slide' );
if (file_exists($path)) {
	require($path);
}  
?>