<?php

// No direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.controllerform');

class NivoSliderControllerSlider extends JControllerForm {
}

?>