DROP TABLE `#__nivoslider`;
DROP TABLE `#__nivoslider_sliders`;